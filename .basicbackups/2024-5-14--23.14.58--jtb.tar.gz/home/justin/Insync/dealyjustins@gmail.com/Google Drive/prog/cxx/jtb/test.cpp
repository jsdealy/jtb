#include <cstring>
#include <iomanip>
#include <stdexcept>
#include <string>
#include <any>
#include <iterator>
#include <iostream>
#include <sstream>
#include <vector>
#include <error.h>
#include "jtbextras.h"
#include "jtbvec.h"
#include "jtbunit.h"
#include "jtbtuple.h"
#include "jtbregex.h"




int main(void) {
    JTB::Vec<int> z;
    z.push(1);
    z.push(2);
    z.push(3);

    JTB::Vec<char> x;
    x.push('a');
    x.push('b');
    x.push('c');

    JTB::Vec<int> y;
    y.push(1);
    y.push(2);

    JTB::Vec<JTB::Str> w;
    w.push("blue");
    w.push("red");

    w += { "green", "orange" };

    w += { "purple" };

    /* JTB::Tup<int, bool, JTB::Str> tup1(192, true, "justin"); */
    /* auto tup = JTB::make_tup(1, false, "bob"); */
    /* std::cout << JTB::Str("splosonkidoodle").split("doo", JTB::Str::SplitMode::LISTINC) << '\n'; */
    /* std::cout << std::string("butt").substr(0, 10) << '\n'; */
    /* JTB::outputMatch<JTB::Vec<JTB::Str>>([](){ JTB::Vec<JTB::Str> t { "so", "k", "&sk" }; return t; }, JTB::Str("sok&sk").split("ok", JTB::Str::SplitMode::LISTINC)); */
    /* JTB::outputMatch<JTB::Vec<JTB::Str>>([](){ JTB::Vec<JTB::Str> t { }; return t; }, JTB::Str(";,;,---,,,").split(",;-", JTB::Str::SplitMode::LISTEXC)); */
    /* std::cout << JTB::Str("sok&skt").split("o&t", JTB::Str::SplitMode::LISTINC) << '\n'; */

    /* JTB::outputMatch<JTB::Str>([]() { JTB::Str s("aspobob"); s.popAt(4, 10); return s;}, JTB::Str("aspo")); */
    /* JTB::outputMatch(JTB::Str("zonkpopo"), JTB::Str("onkpopo").insert("z", 0)); */


    JTB::Str strry { "lkilabblkzonkbonkl" };

    JTB::Regex reg { R"(^[kil]+abb$)" };

    JTB::RegexMatch match = reg.match(strry);

    JTB::Vec<JTB::Str> testvec {};

    int count {0};

    testvec.forEach([&](JTB::Str s) { ++count; return; });

    std::cout << match << '\n';

    std::cout << strry.count("lk") << '\n';

}
